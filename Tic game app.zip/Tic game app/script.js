const startButton = document.getElementById('startButton');
const quitButton = document.getElementById('quitButton');
const gameBoard = document.getElementById('gameBoard');
const endMessage = document.getElementById('endMessage');
const cells = document.querySelectorAll('[data-cell]');
const playerXScoreElement = document.getElementById('playerXScore');
const playerOScoreElement = document.getElementById('playerOScore');
const themeSelector = document.getElementById('themes');

let isXTurn = true;
let playerXScore = 0;
let playerOScore = 0;

startButton.addEventListener('click', startGame);
quitButton.addEventListener('click', quitGame);
themeSelector.addEventListener('change', changeTheme);

function startGame() {
    gameBoard.classList.remove('hidden');
    startButton.classList.add('hidden');
    endMessage.classList.add('hidden');
    resetBoard();
}

function quitGame() {
    gameBoard.classList.add('hidden');
    endMessage.classList.remove('hidden');
    startButton.classList.remove('hidden');
}

function resetBoard() {
    cells.forEach(cell => {
        cell.classList.remove('x');
        cell.classList.remove('o');
        cell.textContent = '';
        cell.addEventListener('click', handleClick, { once: true });
    });
}

function handleClick(e) {
    const cell = e.target;
    const currentClass = isXTurn ? 'x' : 'o';
    placeMark(cell, currentClass);

    if (checkWin(currentClass)) {
        endGame(false);
        updateScore(currentClass);
    } else if (isDraw()) {
        endGame(true);
    } else {
        swapTurns();
    }
}

function placeMark(cell, currentClass) {
    cell.classList.add(currentClass);
    cell.textContent = currentClass.toUpperCase();
}

function swapTurns() {
    isXTurn = !isXTurn;
}

function checkWin(currentClass) {
    const WINNING_COMBINATIONS = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6]
    ];

    return WINNING_COMBINATIONS.some(combination => {
        return combination.every(index => {
            return cells[index].classList.contains(currentClass);
        });
    });
}

function isDraw() {
    return [...cells].every(cell => {
        return cell.classList.contains('x') || cell.classList.contains('o');
    });
}

function endGame(draw) {
    if (draw) {
        alert('Draw!');
    } else {
        alert(`${isXTurn ? 'X' : 'O'} Wins!`);
    }
    resetBoard();
}

function updateScore(currentClass) {
    if (currentClass === 'x') {
        playerXScore++;
        playerXScoreElement.textContent = playerXScore;
    } else {
        playerOScore++;
        playerOScoreElement.textContent = playerOScore;
    }
}

function changeTheme() {
    document.body.className = themeSelector.value;
}
